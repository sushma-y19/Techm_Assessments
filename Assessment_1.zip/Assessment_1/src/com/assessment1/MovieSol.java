package com.assessment1;

import java.util.ArrayList;
import java.util.Scanner;



public class MovieSol {
	public static Movie[] getMovieByGenre(Movie[] movieArray,String searchGenre) {
        ArrayList<Movie> matchedMovies=new ArrayList<>();
        for (Movie movie:movieArray) {
            if (movie.getGenre().equalsIgnoreCase(searchGenre)) {
                matchedMovies.add(movie);
            }
        }
        return matchedMovies.toArray(new Movie[0]);
    }
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
        Movie movies[]=new Movie[4];
        
        for (int i=0;i<4;i++) {
            String movieName=sc.nextLine();
            String company=sc.nextLine();
            String genre=sc.nextLine();
            int budget=sc.nextInt();
            sc.nextLine();
            movies[i] = new Movie(movieName,company,genre,budget);
        }

        String searchGenre=sc.nextLine();   
        Movie result[] = getMovieByGenre(movies, searchGenre);
        
        for (Movie movie:result) {
            if (movie.getBudget()>80000000) 
            {
                System.out.println("High Budget Movie");
            } 
            else 
            {
                System.out.println("Low Budget Movie");
            }

	}

}
}
