package com.assessment1;

import java.util.ArrayList;
import java.util.Scanner;



public class InventorySol {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        Inventory[] inventories = new Inventory[4];
        
        for (int i = 0; i < 4; i++) {
            String inventoryId=sc.nextLine();
            int maximumQuantity=sc.nextInt();
            int currentQuantity=sc.nextInt();
            int threshold=sc.nextInt();
            sc.nextLine(); 
            inventories[i]=new Inventory(inventoryId,maximumQuantity,currentQuantity,threshold);
        }
        int limit=sc.nextInt();
Inventory[] result=replenish(inventories, limit);
        
        for (Inventory inv : result) {
            int threshold = inv.getThreshold();
            String fillingType;
            if(threshold>75) 
            {
                fillingType = "Critical Filling";
            } 
            else 
            if(threshold>=50) {
                fillingType="Moderate Filling";
            } 
            else 
            {
                fillingType="Non-Critical Filling";
            }
            System.out.println(inv.getInventoryId()+" "+fillingType);
        }
	}

	private static Inventory[] replenish(Inventory[] inventories, int limit) {
		ArrayList<Inventory> result=new ArrayList<>();
        for (Inventory inv:inventories) {
            if(inv.getThreshold()<=limit) {
                result.add(inv);
            }
        }
        return result.toArray(new Inventory[0]);
	}
}
