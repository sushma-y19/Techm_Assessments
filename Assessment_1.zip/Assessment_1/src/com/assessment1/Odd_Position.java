package com.assessment1;

import java.util.Scanner;

public class Odd_Position {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		for (int i=1;i<str.length();i+=2) {
            System.out.print(str.charAt(i));
        }

	}

}
