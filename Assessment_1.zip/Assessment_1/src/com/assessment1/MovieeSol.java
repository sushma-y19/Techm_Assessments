package com.assessment1;

import java.util.Scanner;


public class MovieeSol {
	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Moviee movies[]=new Moviee[4];
        
        for(int i=0;i<4;i++) {
            int movieId=sc.nextInt();
            sc.nextLine();  
            String director=sc.nextLine();
            int rating=sc.nextInt();
            int budget=sc.nextInt();
            sc.nextLine();  
            movies[i]=new Moviee(movieId, director, rating, budget);
        }

        String director=sc.nextLine();
        int rating=sc.nextInt();
        int budget=sc.nextInt();
       

        double avgBudget=findAvgBudgetByDirector(movies, director);
        if(avgBudget>0) {
            System.out.println((int)avgBudget);
        } 
        else 
        {
            System.out.println("Sorry!The given director has not yet directed any movie");
        }

        Moviee movie=getMovieByRatingBudget(movies, rating, budget);
        if (movie!=null) {
            System.out.println(movie.getMovieId());
        } else {
            System.out.println("Sorry - No movie is available with the specified rating and budget requirement");
        }
    }

    public static double findAvgBudgetByDirector(Moviee[] movieArray, String director) {
        int sumBudget = 0;
        int count = 0;
        for (Moviee movie : movieArray) {
            if (movie.getDirector().equalsIgnoreCase(director)) {
                sumBudget += movie.getBudget();
                count++;
            }
        }
        if (count == 0) {
            return 0;
        }
        return (double) sumBudget / count;
    }

    public static Moviee getMovieByRatingBudget(Moviee[] movieArray, int rating, int budget) {
        for (Moviee movie : movieArray) {
            if (movie.getRating() == rating && movie.getBudget() == budget) {
                if (budget % rating == 0) {
                    return movie;
                }
            }
        }
        return null;
    }

}
